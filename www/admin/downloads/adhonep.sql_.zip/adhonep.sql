-- phpMyAdmin SQL Dump
-- version 2.11.7
-- http://www.phpmyadmin.net
--
-- Servidor: localhost
-- Tempo de Geração: Set 19, 2009 as 01:40 PM
-- Versão do Servidor: 5.0.51
-- Versão do PHP: 5.2.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Banco de Dados: `adhonep`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `atributospessoais`
--

CREATE TABLE IF NOT EXISTS `atributospessoais` (
  `idatributospessoais` int(10) unsigned NOT NULL auto_increment,
  `atributo` varchar(255) character set latin1 NOT NULL,
  PRIMARY KEY  (`idatributospessoais`),
  KEY `atributo` (`atributo`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

--
-- Extraindo dados da tabela `atributospessoais`
--

INSERT INTO `atributospessoais` (`idatributospessoais`, `atributo`) VALUES
(3, 'Comunicação'),
(1, 'Líder'),
(4, 'Mestre Cerimônia'),
(5, 'Músico'),
(2, 'Preletor');

-- --------------------------------------------------------

--
-- Estrutura da tabela `cidades`
--

CREATE TABLE IF NOT EXISTS `cidades` (
  `idcidades` int(10) unsigned NOT NULL auto_increment,
  `cidade` varchar(100) character set latin1 NOT NULL,
  `imagem` varchar(255) character set latin1 default NULL,
  `desc` text character set latin1,
  PRIMARY KEY  (`idcidades`),
  UNIQUE KEY `cidade` (`cidade`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='Cidades do sistema' AUTO_INCREMENT=11 ;

--
-- Extraindo dados da tabela `cidades`
--

INSERT INTO `cidades` (`idcidades`, `cidade`, `imagem`, `desc`) VALUES
(1, 'Joinville', NULL, 'Cidade de Joinville'),
(2, 'Blumenau', 'adho.gif', 'fdsa fdsa fdsa fdsa<br>'),
(3, 'Itajaí', '00_evento27-09.gif', '?hjyfdjkfgkjfkgf'),
(4, 'Brusque', '07_evento27-09.jpg', '?fdsa fdas fdsa fdsa f<br>'),
(5, 'Florianópolis', '10.jpg', '?fd safdjh djdf<br>'),
(6, 'São Paulo', '07--Apoio-Jovem-26.04_.2008_.jpg', 'saf das fdas fdas fdas<br>'),
(7, 'Lages', 'camila_rodrigues.jpg', '?Cidade de Lages'),
(9, 'Curitiba', NULL, ''),
(10, 'Jaraguá', 'community_users.png', 'fdsaf dsa fdsa fdsa fdsa <br>');

-- --------------------------------------------------------

--
-- Estrutura da tabela `downloads`
--

CREATE TABLE IF NOT EXISTS `downloads` (
  `iddownloads` int(10) unsigned NOT NULL auto_increment,
  `arquivo` varchar(255) NOT NULL,
  `caminho` varchar(255) NOT NULL,
  `uploader` int(10) unsigned NOT NULL,
  `autor` int(10) unsigned default NULL,
  PRIMARY KEY  (`iddownloads`),
  KEY `fk_downloads_pessoas1` (`uploader`),
  KEY `fk_downloads_pessoas2` (`autor`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Extraindo dados da tabela `downloads`
--


-- --------------------------------------------------------

--
-- Estrutura da tabela `locais`
--

CREATE TABLE IF NOT EXISTS `locais` (
  `idlocais` int(10) unsigned NOT NULL auto_increment,
  `local` varchar(255) character set latin1 NOT NULL,
  `endereco` varchar(255) character set latin1 default NULL,
  `bairro` varchar(100) character set latin1 default NULL,
  `telefone` varchar(16) character set latin1 default NULL,
  `desc` text character set latin1,
  `idpessoas` int(10) unsigned NOT NULL,
  `idcidades` int(10) unsigned NOT NULL,
  PRIMARY KEY  (`idlocais`),
  KEY `fk_locais_pessoas1` (`idpessoas`),
  KEY `fk_locais_cidades1` (`idcidades`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=12 ;

--
-- Extraindo dados da tabela `locais`
--

INSERT INTO `locais` (`idlocais`, `local`, `endereco`, `bairro`, `telefone`, `desc`, `idpessoas`, `idcidades`) VALUES
(1, 'Casa do Leonardo', 'Rua Orestes Guimarães, 225 - apto. 604', 'Centro', '4730266908', 'A minha casa<br>', 18, 1),
(2, 'Igreja Santos Anjos', 'Rua da igreja, 45', 'Marinha', '4734372322', 'Igreja revestida em ouro.', 4, 4),
(4, 'Igreja Bola de Neve', 'Rua Felipe Schimit', 'Centro', '4832236578', 'A igreja da mocidade.', 42, 5),
(5, 'Auditório Municipal', 'Rua Central, 123', 'Centro', '(47) 3026-6908', 'Auditório Espaçoso', 43, 6),
(6, 'fdsa', 'fdsafdsa', 'ffdsa', '(47) 3026-6908', '?fdsaffdsafdsaf dsaf dsa fdsa fd<br>', 15, 1),
(7, 'kjhgkjhg', 'kljyhkgkj', 'uirtyr', '54654', '?hgfd ryjh fmjnhdf nhdf<br>', 2, 1),
(8, 'tryreytre', 'gh dfsgfds ', ' gsdf gdsf ', '5432432', 'abacedkajfdlsa<br>', 13, 6),
(9, 'gfsgfds', 'fdsaf dsaf dsa fdsaf dsa', 'f dsa fdsa fds', '543', '&nbsp;fdsafdsaf dsa fdsa<br>', 42, 6),
(10, 'aaaaaaaaaaaaa', 'fdsafdsafdsa', 'fdsafdsafdsafds', '(47) 3026-6908', 'afdsafdsafdsafdsadsaf', 11, 1),
(11, 'dffdsa', 'fdsafdsa', 'fdsaf', '(30) 2669-0808', 'dsafdsafdsafdsa', 42, 7);

-- --------------------------------------------------------

--
-- Estrutura da tabela `permissoes`
--

CREATE TABLE IF NOT EXISTS `permissoes` (
  `idpermissoes` int(10) unsigned NOT NULL auto_increment,
  `permissao` varchar(255) character set latin1 default NULL,
  PRIMARY KEY  (`idpermissoes`),
  KEY `permissao` (`permissao`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=8 ;

--
-- Extraindo dados da tabela `permissoes`
--

INSERT INTO `permissoes` (`idpermissoes`, `permissao`) VALUES
(1, 'agenda'),
(2, 'cidades'),
(3, 'downloads'),
(4, 'locais'),
(5, 'pessoas'),
(6, 'usuarios'),
(7, 'usuários somente na sua cidade');

-- --------------------------------------------------------

--
-- Estrutura da tabela `pessoas`
--

CREATE TABLE IF NOT EXISTS `pessoas` (
  `idpessoas` int(10) unsigned NOT NULL auto_increment,
  `nome` varchar(255) character set latin1 NOT NULL,
  `email` varchar(255) character set latin1 NOT NULL,
  `senha` varchar(50) character set latin1 default NULL,
  `telefone` varchar(16) character set latin1 default NULL,
  `celular` varchar(16) character set latin1 default NULL,
  `endereco` varchar(255) character set latin1 default NULL,
  `bairro` varchar(100) character set latin1 default NULL,
  `idcidades` int(10) unsigned NOT NULL,
  `desc` text character set latin1,
  `acesso` tinyint(1) NOT NULL,
  `permissoes` varchar(255) character set latin1 default NULL,
  PRIMARY KEY  (`idpessoas`),
  UNIQUE KEY `email` (`email`),
  KEY `fk_pessoas_cidades1` (`idcidades`),
  KEY `nome` (`nome`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='Pessoas e Usuários do sistema' AUTO_INCREMENT=63 ;

--
-- Extraindo dados da tabela `pessoas`
--

INSERT INTO `pessoas` (`idpessoas`, `nome`, `email`, `senha`, `telefone`, `celular`, `endereco`, `bairro`, `idcidades`, `desc`, `acesso`, `permissoes`) VALUES
(1, 'Leonardo Lima de Vasconcellos', 'leonardo@devhouse.com.br', '0bc5b422a348b5958aacba5f863dd57f40ced581', '4730266908', '4799442321', 'Rua Orestes Guimarães, 225', 'Centro', 5, 'Programador Web', 1, 'permisso'),
(2, 'Denise Alcântara Bezzera de Lima', 'denise_jlle@hotmail.com', '7c4a8d09ca3762af61e59520943dc26494f8941b', '30266908', '99610414', 'Rua Orestes Guimarães, 225', 'Centro', 1, 'Minha Mãe', 1, NULL),
(3, 'Rafael Lima de Vasconcellos', 'rafael.lima@totvs.com.br', 'da39a3ee5e6b4b0d3255bfef95601890afd80709', '33380232', '781613314', '', '', 1, '', 1, ''),
(4, 'Ismar M.', 'ismar@ldi.com.br', '27f63f5204217f3f80adffeeb92351aa5d9b2c25', '30303030', '99999999', 'Rua Dona Francisca, 5347', 'Bairro', 1, 'Descrição Ismar', 1, NULL),
(5, 'Luis', 'luiz.camargo@agenciadmg.com.br', '123456', '33333333', '99999999', 'Rua Sem Nome, sn', 'Centro', 1, 'Descrição', 1, NULL),
(6, 'Victor Castoldi Vasconcellos', 'victor.castoldi@gmail.com', '7c4a8d09ca3762af61e59520943dc26494f8941b', '30303', '9449459', 'Rua sem nome, sn', 'Bairro', 1, '', 0, 'Permissões'),
(7, 'João da Silva', 'joao@dasilva.com.br', '7c4a8d09ca3762af61e59520943dc26494f8941b', '4732184329', '3243242', 'Rua sem nome,sn', 'bairro', 1, '', 0, 'Permissões'),
(8, 'Nome', 'email@email.com', '7c4a8d09ca3762af61e59520943dc26494f8941b', '46454645', '456456465', 'Rua Sem Nome, sn', 'Bairro', 1, 'fdsafdsafdsa', 0, 'Permisso'),
(9, 'Janjão', 'janjao@email.com', '7751a23fa55170a57e90374df13a3ab78efe0e99', '78908', '989987987', 'rua tal, numero tal', 'Bairro', 1, '', 1, 'Permissões'),
(11, 'Davi Golias', 'fdsajl@fjdaaaaa.com', '7751a23fa55170a57e90374df13a3ab78efe0e99', '57328473', '987459387', 'fjdsaklfjd123', 'Bairro', 2, '', 1, 'Permisso'),
(12, 'Grand Master Flash', 'grand@masterflash.com', '1bdc12f0f29da10f6b637646821c0c56e8c48559', '0987097', '98798798', 'fdsaçl fdjskla flkdsaj flksd', 'fdjsaklfjdsl', 1, '', 1, 'Permissões'),
(13, 'Anacleto Brocolli', 'anacleto@brocoli.com', 'cd3f0c85b158c08a2b113464991810cf2cdfc387', '5432342', '98797897', 'fhdsak fhdsa fj', 'fd salkfjds al', 1, '<br>', 1, 'Permisso'),
(15, 'Edimilson Creison', 'edmilson@creison.com', '7c4a8d09ca3762af61e59520943dc26494f8941b', '5432542', '987987', 'fdsafdsafdsa, sn', 'fdsafdsa', 1, '', 1, 'Permisso'),
(16, 'Juliano Barbosa', 'juliano@barbosa.com', '7c4a8d09ca3762af61e59520943dc26494f8941b', '98798', '98798789', 'fdsafdsa', 'fdsafdsa', 1, '', 1, 'Permissões'),
(17, 'Julian Moore', 'julian@moore.com', '7c4a8d09ca3762af61e59520943dc26494f8941b', '456456', '654654', 'fjad slakfj dsaçlkfj dsalf jdslaj', 'Bairro', 1, '', 1, 'Permissões'),
(18, 'Amina Munsta', 'amina@munsta.com', '7c4a8d09ca3762af61e59520943dc26494f8941b', '09809808', '9674987', 'ds flakfj dlksafj dlksa fldksa jflkdsaj lfd jalkf dlksa djflka jfldaj flkdsa jflkd jsaklf jdaskl fjdklsa fjdlksafdsa fdsa fdsa fdsa fdsa fdas fdsa  fdsa fdsa fdsa fdsa fdsaf dsa fdsa fdsaf dsa fdsaf dsaf  dsaf dsa fdsa ', 'Bairro', 7, 'fdsafdsafdsafdsafds', 0, 'Permisso'),
(19, 'Anastacia Velasco', 'ana@velasco.com', '7c4a8d09ca3762af61e59520943dc26494f8941b', '777777777', '98798498489', 'fdsafdsa fdsa fdsa fdsa fdsa', 'f dsa fdsa fdas fdas dsa', 1, 'dsa <a href="http://www.google.com">fdsaf </a>dsa <b>fdsa </b>fdsa <span style="background-color: rgb(255, 255, 0);">fdsa </span>fdsa <a href="http://www.google.com">fdsa </a>fd <font color="#99cc00">asf </font>dasf dsa dsa d<br>', 1, 'Permisso'),
(20, 'Ludimila Kadinski', 'lulu@kaka.com', '7c4a8d09ca3762af61e59520943dc26494f8941b', '43214321', '43214322', 'fdsafdsafdsafdsa', 'fdsafdsafdsa', 1, 'fdsa <a href="http://www.google.com/">fdsaf </a>dsa <b>fdsa </b>fdsa <span style="background-color: rgb(255, 255, 0);">fdsa </span>fdsa fdsa fd <font color="#99cc00">asf </font>dasf dsa dsa d', 0, 'Permisso'),
(21, 'Ratazana', 'rat@azana.com.br', '7e240de74fb1ed08fa08d38063f6a6a91462a815', '432432432', '432432', 'fdsafdsafdsafdsafdsafdsa', 'fdsafdsa', 1, 'dsafdsaf<font color="#ff6600">dsafdsa</font>fdsa', 1, 'Permisso'),
(22, 'All the fear I have', 'fear@tdv.com', '7c4a8d09ca3762af61e59520943dc26494f8941b', '123456', '98797987', 'endereço 124', 'América', 6, '<img src="images/ajax-loader.gif" vspace="6" align="Esquerda" hspace="6"><br><br><b>All </b><font color="#ff6600">the </font><i>fear </i>I <font color="#ff0000">have </font>is <font color="#339966">only </font><a href="http://www.tdv.com">inside </a><span style="background-color: rgb(255, 102, 0);">my </span><font color="#00ffff">mind</font><br>', 1, 'Permisso'),
(27, 'fdsafdsafd', 'afdsa@fdjsla.com', '7c4a8d09ca3762af61e59520943dc26494f8941b', '54325432', '12312', 'gfdsgfdsg', 'gfdsgfds', 4, 'A descrição está escrita aqui.<br>', 1, 'Permisso'),
(29, 'fjdkslajf', 'leoj@fjdsl.com', '7c4a8d09ca3762af61e59520943dc26494f8941b', '789797', '1234456', 'vsadsafdsafdsaf', 'fdsafdsaf', 1, 'dsafdsafdsa', 1, 'Permisso'),
(31, 'fjdsakljfdls', 'fhdsalk@fvjdslka.com', '7c4a8d09ca3762af61e59520943dc26494f8941b', '1321321', '14564654', 'fdasfdsafdsaf', 'dsafdsafdsaf', 1, 'dsafdsafads', 1, 'Permisso'),
(33, 'Fausta', 'sadfds@fjdls.com', '7c4a8d09ca3762af61e59520943dc26494f8941b', '5465465', '654564', 'fdsafdsafdsa', 'fdsafdsafd', 1, 'ffff', 1, 'Permisso'),
(36, 'fdsafdsa', '123@jfdls.com', '7c4a8d09ca3762af61e59520943dc26494f8941b', '4321321', '1431243', 'fdsafdsafdsa', 'fdsafdsa', 2, 'fdsafdsaf', 1, 'Permisso'),
(40, 'fdsafdsafdsafdsa', 'fjds@dlfkdsa.com', '7c4a8d09ca3762af61e59520943dc26494f8941b', '4321431', '43214321', 'fdsafdsa', 'fdsafdsa', 4, 'fdsafdsa', 0, 'Permisso'),
(41, 'Joey Ramone', 'fddjsajfdj@jfjfjfjfjfjjffjjf.com', '7c4a8d09ca3762af61e59520943dc26494f8941b', '43432432', '432432', 'fdsafdsafdsa, 123', 'bairro', 1, 'dsafd safd asf dsa fdsa fdsa fdsa <br>', 1, 'Permisso'),
(42, 'Bruna Bitencourt', 'bruna@bit.com.br', '7c4a8d09ca3762af61e59520943dc26494f8941b', '4325432432', '432432432', 'fdsafdsafdsaf', 'fdsafdsa', 1, 'yterytreuytreytre', 1, 'Permisso'),
(43, 'HP Lovecraft', 'hp@lovecraft.com', '7c4a8d09ca3762af61e59520943dc26494f8941b', '564654', '456465465', 'fdsafdsafdsafdsafdsa123', 'fdsafdsafdsa', 1, 'aaaaaaaaaaaaaaaaa', 1, 'Permisso'),
(44, 'KKK', 'fdsafaaaaddddsa@fdsajlf.com', '7c4a8d09ca3762af61e59520943dc26494f8941b', '123132', '4564654', 'fdsafdsa', 'fdasfdsa', 1, '?fdsafdsa', 1, 'Permisso'),
(45, 'Camila Rodrigues', 'camila@rodrigues.com.br', '7c4a8d09ca3762af61e59520943dc26494f8941b', '4730335589', '4799748553', 'Rua João Colin, 2345', 'América', 1, '<img src="images/imagens/camila_rodrigues.jpg" align="left" hspace="6" vspace="6">?Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse facilisis ligula sed ligula luctus congue. Fusce venenatis, lorem vitae porttitor lobortis, ipsum nunc facilisis ipsum, ac feugiat orci purus id velit. Maecenas vel lorem non magna eleifend varius et vel dui. Maecenas ut quam velit, ut gravida dolor. Aenean at enim risus, non feugiat ipsum. Nunc bibendum convallis tellus, porttitor dignissim leo fringilla ac. Curabitur congue enim ut quam placerat in interdum massa vestibulum. Duis sollicitudin elit et magna molestie vitae gravida est consequat. Quisque placerat, ante sit amet posuere suscipit, nibh magna posuere libero, rutrum consectetur elit nulla vitae nisl. Sed interdum laoreet justo vestibulum malesuada. Donec mattis volutpat mattis.<div><br></div><div>Etiam vitae sollicitudin lorem. Ut rhoncus purus eu ipsum bibendum tempor. Vestibulum scelerisque laoreet luctus. Aenean vehicula porttitor enim, eu bibendum diam blandit et. Proin sem libero, dapibus sit amet suscipit non, commodo eget nisl. Vivamus vitae arcu nisl, euismod egestas neque. In sed iaculis nulla. Quisque porttitor erat et ligula rutrum mollis pretium mi scelerisque. Mauris ornare porttitor volutpat. Donec eget quam mauris, eu aliquet massa. In dictum auctor dolor, a aliquam arcu mattis sit amet. Morbi et augue non turpis blandit convallis. Praesent at augue sapien, eu gravida leo. Morbi fringilla rutrum cursus. Etiam vitae ante et odio adipiscing convallis eu at lectus. Aenean auctor tortor ut urna egestas a tincidunt nisi commodo. Sed sed diam at orci elementum adipiscing.</div><div><br></div><div>Proin ut felis ut nisl sodales porta. Donec in eros vel nisi aliquet egestas gravida aliquet massa. Suspendisse facilisis viverra purus, vitae malesuada tortor vestibulum nec. Suspendisse quis tincidunt leo. Aliquam cursus commodo neque non suscipit. In molestie sagittis risus, sed euismod arcu lobortis quis. Integer et velit et ante semper scelerisque sed at tellus. Phasellus ornare dictum odio, at feugiat turpis venenatis id. Cras sed felis nunc. Etiam magna leo, ullamcorper quis ultricies eu, ultrices ut nisl. In hac habitasse platea dictumst. Vivamus ultrices, orci et ultricies tincidunt, mauris magna egestas leo, eu molestie purus metus id nibh. Nulla id ultricies magna. Duis tincidunt, dui vestibulum sagittis tempus, lorem felis suscipit sapien, ut porttitor dui urna non nibh.</div><div><br></div><div>Integer a turpis lorem. Pellentesque ac ullamcorper neque. Sed in turpis a dolor imperdiet egestas. Integer porttitor pulvinar lacinia. Sed nibh turpis, fermentum a venenatis ac, aliquet eu nisi. Nam arcu lectus, dignissim vel scelerisque non, facilisis non arcu. Vestibulum quis nibh dui. Nunc non nunc sed odio tincidunt hendrerit sollicitudin sit amet sem. Nunc congue pulvinar hendrerit. Vestibulum ut felis sapien, quis tincidunt erat. Nullam interdum purus ut eros consequat dignissim. Duis vehicula vestibulum tortor, et porttitor odio elementum at. Praesent vel tortor non orci lacinia pellentesque ac vitae massa. Proin eget facilisis risus. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum egestas, eros ac tincidunt pretium, leo dui pellentesque nisl, non hendrerit libero odio ac eros. Nam posuere, urna non cursus vulputate, eros eros luctus ligula, nec congue tortor orci at felis.</div><div><br></div><div>Aliquam nunc dolor, congue et commodo non, laoreet sit amet orci. Donec euismod lobortis dictum. Sed malesuada fringilla sem, a facilisis justo scelerisque et. Vivamus rutrum lectus et dui hendrerit facilisis. Vestibulum enim massa, fermentum et luctus sed, suscipit a felis. Sed aliquet volutpat pharetra. Aliquam rutrum, lectus at varius rutrum, ante leo sollicitudin magna, sit amet dapibus orci erat vel quam. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Aenean id dignissim velit. Maecenas tristique nisi erat. Nunc dapibus aliquam nulla, at placerat leo auctor vel. Quisque feugiat urna quis libero facilisis volutpat.&nbsp;</div>', 1, 'Permisso'),
(46, 'Oswaldo Marques', 'oswaldo@marques.com.br', '7c4a8d09ca3762af61e59520943dc26494f8941b', '(41) 2323-5465', '(41) 9955-2322', 'Rua sem nome,sn', 'Batel', 9, 'fdsafdsadsafsa', 1, 'Permisso'),
(47, 'fdsafdsa', 'fdsafd@fdsacc.net', '7c4a8d09ca3762af61e59520943dc26494f8941b', '(63) 2563-2564', '(24) 3243-2432', 'fdsafdsafdsa', 'fdsafdsa', 9, 'fdsafdsafdsa', 1, 'Permisso'),
(48, 'qqqqqqqqq', 'qq@qaqq.com', '7c4a8d09ca3762af61e59520943dc26494f8941b', '(63) 4523-5432', '(23) 3223-3421', 'afdsafdsafdsa', 'fdsafdsa', 2, 'fdsafdsafdsa', 1, 'Permisso'),
(49, 'aaaaaaaaaaa', 'gfdsgfs@ggghhhjjkkj.org', '7c4a8d09ca3762af61e59520943dc26494f8941b', '(43) 2143-2143', '(43) 2432-1543', 'fdsafdsafdsa', 'fdsafdsa', 3, 'fdsafdsafdsafd', 1, 'Permisso'),
(50, 'bbbbbbbbb', 'bb@bb.net', '7c4a8d09ca3762af61e59520943dc26494f8941b', '(43) 2432-1423', '(23) 4324-3242', 'fdsafdsafdsafdsafdsafdsa', 'fdsafdsafdsa', 4, 'fdsa fdsa fdsa fda f dsa fdsa fdsa<br>', 1, 'Permisso'),
(51, 'cccccccc', 'ccc@ccccc.com', '7c4a8d09ca3762af61e59520943dc26494f8941b', '(43) 2143-1431', '(43) 2412-4321', 'fdsadsafdsafdsa', 'fdsafdsa', 6, 'hgagafgda sfdsa fdsa fdsa fdsa fdsa<br>', 1, 'Permisso'),
(52, 'ddddd', 'ddd@fdsa.com', '7c4a8d09ca3762af61e59520943dc26494f8941b', '(43) 2143-2143', '(32) 1432-1432', 'fdsafdsafdsa', 'fdsafdsafdsa', 5, 'safdsafdsafdsafdsafdsa fdsa fdsa fdsa fdsa fdsa fdsa fdsa fdsa fdsa <br>', 1, 'Permisso'),
(53, 'Monica', 'm@monica.com', '7c4a8d09ca3762af61e59520943dc26494f8941b', '(43) 2451-3243', '(31) 2432-1431', 'fdsa fdsa fdsaf dsa fdsa', ' fdsa fdsa fdsa', 2, 'f dsafdsa fdsa fdsa fdas fdsa fdsa <br>', 1, 'Permisso'),
(54, 'Robert Langdon', 'robert@langdon.com', '7c4a8d09ca3762af61e59520943dc26494f8941b', '(45) 6456-4564', '(45) 6456-4654', 'fdsafdsafdsa', 'fdsafdsa', 7, 'f dsafd <font color="#ff0000">safdsa </font>fdsa <span style="background-color: rgb(153, 204, 0);">fdsa </span>fdsa <b>fdsaf </b>dsa<br>', 1, 'Permisso'),
(55, 'Altamiro Lima', 'altamiro@lima.com', '7c4a8d09ca3762af61e59520943dc26494f8941b', '(45) 6464-5646', '(64) 6546-5446', 'fdsaf dsa dfsa fdsa fdsa', 'fdsafdsa', 7, '<b>fdsa </b>fdsa <font color="#ff0000">fdsaf </font>dsa fdsa <span style="background-color: rgb(255, 255, 0);">fdsa </span>fsa<br>', 1, 'Permisso'),
(56, 'Jhon Lenon', 'john@beatles.com', '7c4a8d09ca3762af61e59520943dc26494f8941b', '(56) 4654-6465', '(46) 4654-6546', 'fdsafdsafdsa', 'fdsafdsafdsa', 4, 'fdsaf dsa fdsa fdsa fdsa<br>', 1, 'Permisso'),
(57, 'Ronaldinho', 'ronaldo@selecao.com.br', '7c4a8d09ca3762af61e59520943dc26494f8941b', '(45) 4645-6465', '(56) 4646-5464', 'fdsafdsafdsa', 'fdsafdsa', 5, 'fdsafdsa fdsa fdsa fdsa fdsa fdsa fdsa<br>', 1, 'Permisso'),
(58, 'Abadia Coristalina', 'abadia@fjdks.com', '53b722fe6a32e35699af061920916a4b927f4a61', '(45) 6464-6546', '(65) 4465-4564', 'fdsafdsafda', 'fdsafdsaf', 9, '<img src="images/add.png" vspace="6" align="left" hspace="6">fd asfd safdas fdsah tequ hg hgs htda hdat<img src="images/imagens/camila_rodrigues.jpg" vspace="6" align="right" hspace="6">', 0, 'Permisso'),
(59, 'a', 'a@a.com', '7c4a8d09ca3762af61e59520943dc26494f8941b', '(32) 1432-1431', '(43) 2143-2143', 'fdsafdsaf', 'fdasfdsa', 5, 'fdsa fdsa fdsa fdsa fdsaf dsaf dsaf dsa fdsa fds<br>', 1, 'Permisso'),
(60, 'aa', 'aa@fdsa.com', '7c4a8d09ca3762af61e59520943dc26494f8941b', '(23) 4153-2143', '(65) 4654-5665', '1231d3saf1d3safdsa', 'fdafdsa', 9, 'fdsafdas fdsoaf ldkçsaj fdsaj fdsaj fçldsaj fçldasj flçkds jalkfj dslçaj <br>', 1, 'Permisso'),
(61, 'aaa', 'aaa@fdasfdsa.com', '7c4a8d09ca3762af61e59520943dc26494f8941b', '(54) 3254-3254', '(52) 4325-4325', 'fdsafdsafdsafd', 'fdsafdsa', 2, 'fdsafdsafdsafdsa', 1, 'Permisso'),
(62, 'b', 'afdasf@fdasfs.com', '7c4a8d09ca3762af61e59520943dc26494f8941b', '(54) 3254-3254', '(54) 3254-3254', 'afdsafdsa fdsa fdfdas ', 'fdasfdsafdsa', 2, '&nbsp;fdsaf dsaf dsaf dsa fdsa fdsa fdsa fdsa<br>', 1, 'Permisso');

-- --------------------------------------------------------

--
-- Estrutura da tabela `pessoas_atributospessoais`
--

CREATE TABLE IF NOT EXISTS `pessoas_atributospessoais` (
  `idpessoas` int(10) unsigned NOT NULL,
  `idatributospessoais` int(10) unsigned NOT NULL,
  PRIMARY KEY  (`idpessoas`,`idatributospessoais`),
  KEY `fk_pessoas_has_atributospessoais_pessoas1` (`idpessoas`),
  KEY `fk_pessoas_has_atributospessoais_atributospessoais1` (`idatributospessoais`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `pessoas_atributospessoais`
--

INSERT INTO `pessoas_atributospessoais` (`idpessoas`, `idatributospessoais`) VALUES
(22, 3),
(49, 2),
(57, 1),
(57, 2),
(57, 3),
(57, 4),
(58, 3),
(59, 1),
(59, 2),
(59, 3),
(59, 4),
(59, 5),
(60, 1),
(60, 2),
(60, 3),
(60, 4),
(60, 5),
(61, 1),
(61, 2),
(61, 3),
(61, 4),
(61, 5),
(62, 1),
(62, 2),
(62, 3),
(62, 4),
(62, 5);

-- --------------------------------------------------------

--
-- Estrutura da tabela `pessoas_cidades`
--

CREATE TABLE IF NOT EXISTS `pessoas_cidades` (
  `pessoas_idpessoas` int(10) unsigned NOT NULL,
  `cidades_idcidades` int(10) unsigned NOT NULL,
  PRIMARY KEY  (`pessoas_idpessoas`,`cidades_idcidades`),
  KEY `fk_pessoas_has_cidades_pessoas` (`pessoas_idpessoas`),
  KEY `fk_pessoas_has_cidades_cidades` (`cidades_idcidades`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `pessoas_cidades`
--


-- --------------------------------------------------------

--
-- Estrutura da tabela `pessoas_permissoes`
--

CREATE TABLE IF NOT EXISTS `pessoas_permissoes` (
  `idpessoas` int(10) unsigned NOT NULL,
  `idpermissoes` int(10) unsigned NOT NULL,
  PRIMARY KEY  (`idpessoas`,`idpermissoes`),
  KEY `fk_pessoas_has_permissoes_pessoas1` (`idpessoas`),
  KEY `fk_pessoas_has_permissoes_permissoes1` (`idpermissoes`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `pessoas_permissoes`
--

INSERT INTO `pessoas_permissoes` (`idpessoas`, `idpermissoes`) VALUES
(19, 1),
(22, 5),
(58, 1),
(58, 2),
(58, 3),
(58, 4),
(58, 5),
(58, 7);

--
-- Restrições para as tabelas dumpadas
--

--
-- Restrições para a tabela `downloads`
--
ALTER TABLE `downloads`
  ADD CONSTRAINT `fk_downloads_pessoas1` FOREIGN KEY (`uploader`) REFERENCES `pessoas` (`idpessoas`) ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_downloads_pessoas2` FOREIGN KEY (`autor`) REFERENCES `pessoas` (`idpessoas`) ON UPDATE NO ACTION;

--
-- Restrições para a tabela `locais`
--
ALTER TABLE `locais`
  ADD CONSTRAINT `fk_locais_cidades1` FOREIGN KEY (`idcidades`) REFERENCES `cidades` (`idcidades`) ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_locais_pessoas1` FOREIGN KEY (`idpessoas`) REFERENCES `pessoas` (`idpessoas`) ON UPDATE CASCADE;

--
-- Restrições para a tabela `pessoas`
--
ALTER TABLE `pessoas`
  ADD CONSTRAINT `fk_pessoas_cidades1` FOREIGN KEY (`idcidades`) REFERENCES `cidades` (`idcidades`) ON UPDATE CASCADE;

--
-- Restrições para a tabela `pessoas_atributospessoais`
--
ALTER TABLE `pessoas_atributospessoais`
  ADD CONSTRAINT `fk_pessoas_has_atributospessoais_atributospessoais1` FOREIGN KEY (`idatributospessoais`) REFERENCES `atributospessoais` (`idatributospessoais`) ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_pessoas_has_atributospessoais_pessoas1` FOREIGN KEY (`idpessoas`) REFERENCES `pessoas` (`idpessoas`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Restrições para a tabela `pessoas_cidades`
--
ALTER TABLE `pessoas_cidades`
  ADD CONSTRAINT `fk_pessoas_has_cidades_cidades` FOREIGN KEY (`cidades_idcidades`) REFERENCES `cidades` (`idcidades`) ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_pessoas_has_cidades_pessoas` FOREIGN KEY (`pessoas_idpessoas`) REFERENCES `pessoas` (`idpessoas`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Restrições para a tabela `pessoas_permissoes`
--
ALTER TABLE `pessoas_permissoes`
  ADD CONSTRAINT `fk_pessoas_has_permissoes_permissoes1` FOREIGN KEY (`idpermissoes`) REFERENCES `permissoes` (`idpermissoes`) ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_pessoas_has_permissoes_pessoas1` FOREIGN KEY (`idpessoas`) REFERENCES `pessoas` (`idpessoas`) ON DELETE CASCADE ON UPDATE CASCADE;
